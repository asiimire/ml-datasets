
DATABASE_URI = 'postgres+psycopg2://postgres:password@localhost:5432/books'
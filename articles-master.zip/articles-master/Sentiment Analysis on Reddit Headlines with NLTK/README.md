Link to post: [Sentiment Analysis on Reddit News Headlines with Python’s Natural Language Toolkit (NLTK)](https://www.learndatasci.com/sentiment-analysis-reddit-headlines-pythons-nltk/)

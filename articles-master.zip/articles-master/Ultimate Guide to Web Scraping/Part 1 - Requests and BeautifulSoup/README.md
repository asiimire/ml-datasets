You can either go through the iPython notebook, which has the entire article and code, or run the scraping script directly.

To run the script directly:

+ Install the requirements: `pip install requests bs4 tqdm`
+ Navigate to script's directory and run: `python script.py`

Print statements were added so you should see some output about the script's status.
